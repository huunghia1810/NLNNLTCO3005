# Generated from main/bkool/parser/BKOOL.g4 by ANTLR 4.9.2
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO


def serializedATN():
    with StringIO() as buf:
        buf.write("\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\27")
        buf.write("\u00b4\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7")
        buf.write("\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t\13\4\f\t\f\4\r\t\r\4\16")
        buf.write("\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22\4\23\t\23")
        buf.write("\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30\3\2")
        buf.write("\3\2\6\2\63\n\2\r\2\16\2\64\3\2\3\2\3\3\3\3\3\3\3\3\3")
        buf.write("\3\3\4\3\4\3\4\3\4\3\5\3\5\5\5D\n\5\3\6\3\6\3\6\3\6\3")
        buf.write("\6\5\6K\n\6\3\7\3\7\3\7\3\b\3\b\3\b\3\b\3\t\3\t\3\t\3")
        buf.write("\t\5\tX\n\t\3\n\3\n\3\n\3\n\5\n^\n\n\3\13\3\13\3\13\3")
        buf.write("\13\3\f\3\f\3\f\3\f\3\f\3\r\3\r\3\r\3\r\3\r\3\r\3\16\3")
        buf.write("\16\3\16\3\16\3\17\3\17\3\17\3\17\5\17w\n\17\3\20\3\20")
        buf.write("\3\20\3\20\3\20\5\20~\n\20\3\21\3\21\3\21\3\21\3\21\5")
        buf.write("\21\u0085\n\21\3\22\3\22\3\22\3\22\3\22\3\22\7\22\u008d")
        buf.write("\n\22\f\22\16\22\u0090\13\22\3\23\3\23\3\23\3\23\3\23")
        buf.write("\5\23\u0097\n\23\3\24\3\24\3\24\3\24\3\24\3\25\3\25\3")
        buf.write("\25\3\25\3\26\3\26\3\26\7\26\u00a5\n\26\f\26\16\26\u00a8")
        buf.write("\13\26\5\26\u00aa\n\26\3\27\3\27\3\30\3\30\3\30\3\30\5")
        buf.write("\30\u00b2\n\30\3\30\2\3\"\31\2\4\6\b\n\f\16\20\22\24\26")
        buf.write("\30\32\34\36 \"$&(*,.\2\4\3\2\6\7\3\2\r\16\2\u00af\2\62")
        buf.write("\3\2\2\2\48\3\2\2\2\6=\3\2\2\2\bC\3\2\2\2\nJ\3\2\2\2\f")
        buf.write("L\3\2\2\2\16O\3\2\2\2\20W\3\2\2\2\22]\3\2\2\2\24_\3\2")
        buf.write("\2\2\26c\3\2\2\2\30h\3\2\2\2\32n\3\2\2\2\34v\3\2\2\2\36")
        buf.write("}\3\2\2\2 \u0084\3\2\2\2\"\u0086\3\2\2\2$\u0096\3\2\2")
        buf.write("\2&\u0098\3\2\2\2(\u009d\3\2\2\2*\u00a9\3\2\2\2,\u00ab")
        buf.write("\3\2\2\2.\u00b1\3\2\2\2\60\63\5\24\13\2\61\63\5\4\3\2")
        buf.write("\62\60\3\2\2\2\62\61\3\2\2\2\63\64\3\2\2\2\64\62\3\2\2")
        buf.write("\2\64\65\3\2\2\2\65\66\3\2\2\2\66\67\7\2\2\3\67\3\3\2")
        buf.write("\2\289\5,\27\29:\7\21\2\2:;\5\6\4\2;<\5\16\b\2<\5\3\2")
        buf.write("\2\2=>\7\t\2\2>?\5\b\5\2?@\7\n\2\2@\7\3\2\2\2AD\5\n\6")
        buf.write("\2BD\3\2\2\2CA\3\2\2\2CB\3\2\2\2D\t\3\2\2\2EF\5\f\7\2")
        buf.write("FG\7\b\2\2GH\5\n\6\2HK\3\2\2\2IK\5\f\7\2JE\3\2\2\2JI\3")
        buf.write("\2\2\2K\13\3\2\2\2LM\5,\27\2MN\5.\30\2N\r\3\2\2\2OP\7")
        buf.write("\13\2\2PQ\5\20\t\2QR\7\f\2\2R\17\3\2\2\2ST\5\22\n\2TU")
        buf.write("\5\20\t\2UX\3\2\2\2VX\3\2\2\2WS\3\2\2\2WV\3\2\2\2X\21")
        buf.write("\3\2\2\2Y^\5\24\13\2Z^\5\26\f\2[^\5\30\r\2\\^\5\32\16")
        buf.write("\2]Y\3\2\2\2]Z\3\2\2\2][\3\2\2\2]\\\3\2\2\2^\23\3\2\2")
        buf.write("\2_`\5,\27\2`a\5.\30\2ab\7\b\2\2b\25\3\2\2\2cd\7\21\2")
        buf.write("\2de\7\20\2\2ef\5\36\20\2fg\7\b\2\2g\27\3\2\2\2hi\7\21")
        buf.write("\2\2ij\7\t\2\2jk\5*\26\2kl\7\n\2\2lm\7\b\2\2m\31\3\2\2")
        buf.write("\2no\7\3\2\2op\5\36\20\2pq\7\b\2\2q\33\3\2\2\2rs\7\21")
        buf.write("\2\2st\7\17\2\2tw\5\34\17\2uw\3\2\2\2vr\3\2\2\2vu\3\2")
        buf.write("\2\2w\35\3\2\2\2xy\5 \21\2yz\7\4\2\2z{\5\36\20\2{~\3\2")
        buf.write("\2\2|~\5 \21\2}x\3\2\2\2}|\3\2\2\2~\37\3\2\2\2\177\u0080")
        buf.write("\5\"\22\2\u0080\u0081\7\5\2\2\u0081\u0082\5\"\22\2\u0082")
        buf.write("\u0085\3\2\2\2\u0083\u0085\5\"\22\2\u0084\177\3\2\2\2")
        buf.write("\u0084\u0083\3\2\2\2\u0085!\3\2\2\2\u0086\u0087\b\22\1")
        buf.write("\2\u0087\u0088\5$\23\2\u0088\u008e\3\2\2\2\u0089\u008a")
        buf.write("\f\4\2\2\u008a\u008b\t\2\2\2\u008b\u008d\5$\23\2\u008c")
        buf.write("\u0089\3\2\2\2\u008d\u0090\3\2\2\2\u008e\u008c\3\2\2\2")
        buf.write("\u008e\u008f\3\2\2\2\u008f#\3\2\2\2\u0090\u008e\3\2\2")
        buf.write("\2\u0091\u0097\7\22\2\2\u0092\u0097\7\23\2\2\u0093\u0097")
        buf.write("\7\21\2\2\u0094\u0097\5&\24\2\u0095\u0097\5(\25\2\u0096")
        buf.write("\u0091\3\2\2\2\u0096\u0092\3\2\2\2\u0096\u0093\3\2\2\2")
        buf.write("\u0096\u0094\3\2\2\2\u0096\u0095\3\2\2\2\u0097%\3\2\2")
        buf.write("\2\u0098\u0099\7\21\2\2\u0099\u009a\7\t\2\2\u009a\u009b")
        buf.write("\5*\26\2\u009b\u009c\7\n\2\2\u009c\'\3\2\2\2\u009d\u009e")
        buf.write("\7\t\2\2\u009e\u009f\5\36\20\2\u009f\u00a0\7\n\2\2\u00a0")
        buf.write(")\3\2\2\2\u00a1\u00a6\5\36\20\2\u00a2\u00a3\7\17\2\2\u00a3")
        buf.write("\u00a5\5*\26\2\u00a4\u00a2\3\2\2\2\u00a5\u00a8\3\2\2\2")
        buf.write("\u00a6\u00a4\3\2\2\2\u00a6\u00a7\3\2\2\2\u00a7\u00aa\3")
        buf.write("\2\2\2\u00a8\u00a6\3\2\2\2\u00a9\u00a1\3\2\2\2\u00a9\u00aa")
        buf.write("\3\2\2\2\u00aa+\3\2\2\2\u00ab\u00ac\t\3\2\2\u00ac-\3\2")
        buf.write("\2\2\u00ad\u00ae\7\21\2\2\u00ae\u00af\7\17\2\2\u00af\u00b2")
        buf.write("\5.\30\2\u00b0\u00b2\7\21\2\2\u00b1\u00ad\3\2\2\2\u00b1")
        buf.write("\u00b0\3\2\2\2\u00b2/\3\2\2\2\20\62\64CJW]v}\u0084\u008e")
        buf.write("\u0096\u00a6\u00a9\u00b1")
        return buf.getvalue()


class BKOOLParser ( Parser ):

    grammarFileName = "BKOOL.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'return'", "'+'", "'-'", "'*'", "'/'", 
                     "';'", "'('", "')'", "'{'", "'}'", "'int'", "'float'", 
                     "','", "'='" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "ADD", "SUB", "MUL", "DIV", 
                      "COMMA", "LB", "RB", "LCB", "RCB", "INT", "FLOAT", 
                      "SEMI", "EQ", "ID", "INTLIT", "FLOATLIT", "WS", "ERROR_CHAR", 
                      "UNCLOSE_STRING", "ILLEGAL_ESCAPE" ]

    RULE_program = 0
    RULE_funcdecl = 1
    RULE_paramdef = 2
    RULE_paramlist = 3
    RULE_parampatch = 4
    RULE_param = 5
    RULE_body = 6
    RULE_stmtlist = 7
    RULE_stmt = 8
    RULE_vardecl = 9
    RULE_assignstmt = 10
    RULE_callstmt = 11
    RULE_returnstmt = 12
    RULE_paramdecl = 13
    RULE_exp = 14
    RULE_exp1 = 15
    RULE_exp2 = 16
    RULE_exp3 = 17
    RULE_callexp = 18
    RULE_subexp = 19
    RULE_explist = 20
    RULE_tp = 21
    RULE_idlist = 22

    ruleNames =  [ "program", "funcdecl", "paramdef", "paramlist", "parampatch", 
                   "param", "body", "stmtlist", "stmt", "vardecl", "assignstmt", 
                   "callstmt", "returnstmt", "paramdecl", "exp", "exp1", 
                   "exp2", "exp3", "callexp", "subexp", "explist", "tp", 
                   "idlist" ]

    EOF = Token.EOF
    T__0=1
    ADD=2
    SUB=3
    MUL=4
    DIV=5
    COMMA=6
    LB=7
    RB=8
    LCB=9
    RCB=10
    INT=11
    FLOAT=12
    SEMI=13
    EQ=14
    ID=15
    INTLIT=16
    FLOATLIT=17
    WS=18
    ERROR_CHAR=19
    UNCLOSE_STRING=20
    ILLEGAL_ESCAPE=21

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.9.2")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class ProgramContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def EOF(self):
            return self.getToken(BKOOLParser.EOF, 0)

        def vardecl(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(BKOOLParser.VardeclContext)
            else:
                return self.getTypedRuleContext(BKOOLParser.VardeclContext,i)


        def funcdecl(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(BKOOLParser.FuncdeclContext)
            else:
                return self.getTypedRuleContext(BKOOLParser.FuncdeclContext,i)


        def getRuleIndex(self):
            return BKOOLParser.RULE_program

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitProgram" ):
                return visitor.visitProgram(self)
            else:
                return visitor.visitChildren(self)




    def program(self):

        localctx = BKOOLParser.ProgramContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_program)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 48 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 48
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,0,self._ctx)
                if la_ == 1:
                    self.state = 46
                    self.vardecl()
                    pass

                elif la_ == 2:
                    self.state = 47
                    self.funcdecl()
                    pass


                self.state = 50 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not (_la==BKOOLParser.INT or _la==BKOOLParser.FLOAT):
                    break

            self.state = 52
            self.match(BKOOLParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FuncdeclContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def tp(self):
            return self.getTypedRuleContext(BKOOLParser.TpContext,0)


        def ID(self):
            return self.getToken(BKOOLParser.ID, 0)

        def paramdef(self):
            return self.getTypedRuleContext(BKOOLParser.ParamdefContext,0)


        def body(self):
            return self.getTypedRuleContext(BKOOLParser.BodyContext,0)


        def getRuleIndex(self):
            return BKOOLParser.RULE_funcdecl

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFuncdecl" ):
                return visitor.visitFuncdecl(self)
            else:
                return visitor.visitChildren(self)




    def funcdecl(self):

        localctx = BKOOLParser.FuncdeclContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_funcdecl)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 54
            self.tp()
            self.state = 55
            self.match(BKOOLParser.ID)
            self.state = 56
            self.paramdef()
            self.state = 57
            self.body()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParamdefContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LB(self):
            return self.getToken(BKOOLParser.LB, 0)

        def paramlist(self):
            return self.getTypedRuleContext(BKOOLParser.ParamlistContext,0)


        def RB(self):
            return self.getToken(BKOOLParser.RB, 0)

        def getRuleIndex(self):
            return BKOOLParser.RULE_paramdef

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParamdef" ):
                return visitor.visitParamdef(self)
            else:
                return visitor.visitChildren(self)




    def paramdef(self):

        localctx = BKOOLParser.ParamdefContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_paramdef)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 59
            self.match(BKOOLParser.LB)
            self.state = 60
            self.paramlist()
            self.state = 61
            self.match(BKOOLParser.RB)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParamlistContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def parampatch(self):
            return self.getTypedRuleContext(BKOOLParser.ParampatchContext,0)


        def getRuleIndex(self):
            return BKOOLParser.RULE_paramlist

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParamlist" ):
                return visitor.visitParamlist(self)
            else:
                return visitor.visitChildren(self)




    def paramlist(self):

        localctx = BKOOLParser.ParamlistContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_paramlist)
        try:
            self.state = 65
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [BKOOLParser.INT, BKOOLParser.FLOAT]:
                self.enterOuterAlt(localctx, 1)
                self.state = 63
                self.parampatch()
                pass
            elif token in [BKOOLParser.RB]:
                self.enterOuterAlt(localctx, 2)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParampatchContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def param(self):
            return self.getTypedRuleContext(BKOOLParser.ParamContext,0)


        def COMMA(self):
            return self.getToken(BKOOLParser.COMMA, 0)

        def parampatch(self):
            return self.getTypedRuleContext(BKOOLParser.ParampatchContext,0)


        def getRuleIndex(self):
            return BKOOLParser.RULE_parampatch

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParampatch" ):
                return visitor.visitParampatch(self)
            else:
                return visitor.visitChildren(self)




    def parampatch(self):

        localctx = BKOOLParser.ParampatchContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_parampatch)
        try:
            self.state = 72
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,3,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 67
                self.param()
                self.state = 68
                self.match(BKOOLParser.COMMA)
                self.state = 69
                self.parampatch()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 71
                self.param()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParamContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def tp(self):
            return self.getTypedRuleContext(BKOOLParser.TpContext,0)


        def idlist(self):
            return self.getTypedRuleContext(BKOOLParser.IdlistContext,0)


        def getRuleIndex(self):
            return BKOOLParser.RULE_param

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParam" ):
                return visitor.visitParam(self)
            else:
                return visitor.visitChildren(self)




    def param(self):

        localctx = BKOOLParser.ParamContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_param)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 74
            self.tp()
            self.state = 75
            self.idlist()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LCB(self):
            return self.getToken(BKOOLParser.LCB, 0)

        def stmtlist(self):
            return self.getTypedRuleContext(BKOOLParser.StmtlistContext,0)


        def RCB(self):
            return self.getToken(BKOOLParser.RCB, 0)

        def getRuleIndex(self):
            return BKOOLParser.RULE_body

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBody" ):
                return visitor.visitBody(self)
            else:
                return visitor.visitChildren(self)




    def body(self):

        localctx = BKOOLParser.BodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_body)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 77
            self.match(BKOOLParser.LCB)
            self.state = 78
            self.stmtlist()
            self.state = 79
            self.match(BKOOLParser.RCB)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StmtlistContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def stmt(self):
            return self.getTypedRuleContext(BKOOLParser.StmtContext,0)


        def stmtlist(self):
            return self.getTypedRuleContext(BKOOLParser.StmtlistContext,0)


        def getRuleIndex(self):
            return BKOOLParser.RULE_stmtlist

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStmtlist" ):
                return visitor.visitStmtlist(self)
            else:
                return visitor.visitChildren(self)




    def stmtlist(self):

        localctx = BKOOLParser.StmtlistContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_stmtlist)
        try:
            self.state = 85
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [BKOOLParser.T__0, BKOOLParser.INT, BKOOLParser.FLOAT, BKOOLParser.ID]:
                self.enterOuterAlt(localctx, 1)
                self.state = 81
                self.stmt()
                self.state = 82
                self.stmtlist()
                pass
            elif token in [BKOOLParser.RCB]:
                self.enterOuterAlt(localctx, 2)

                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class StmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def vardecl(self):
            return self.getTypedRuleContext(BKOOLParser.VardeclContext,0)


        def assignstmt(self):
            return self.getTypedRuleContext(BKOOLParser.AssignstmtContext,0)


        def callstmt(self):
            return self.getTypedRuleContext(BKOOLParser.CallstmtContext,0)


        def returnstmt(self):
            return self.getTypedRuleContext(BKOOLParser.ReturnstmtContext,0)


        def getRuleIndex(self):
            return BKOOLParser.RULE_stmt

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitStmt" ):
                return visitor.visitStmt(self)
            else:
                return visitor.visitChildren(self)




    def stmt(self):

        localctx = BKOOLParser.StmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_stmt)
        try:
            self.state = 91
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,5,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 87
                self.vardecl()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 88
                self.assignstmt()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 89
                self.callstmt()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 90
                self.returnstmt()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class VardeclContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def tp(self):
            return self.getTypedRuleContext(BKOOLParser.TpContext,0)


        def idlist(self):
            return self.getTypedRuleContext(BKOOLParser.IdlistContext,0)


        def COMMA(self):
            return self.getToken(BKOOLParser.COMMA, 0)

        def getRuleIndex(self):
            return BKOOLParser.RULE_vardecl

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitVardecl" ):
                return visitor.visitVardecl(self)
            else:
                return visitor.visitChildren(self)




    def vardecl(self):

        localctx = BKOOLParser.VardeclContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_vardecl)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 93
            self.tp()
            self.state = 94
            self.idlist()
            self.state = 95
            self.match(BKOOLParser.COMMA)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AssignstmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(BKOOLParser.ID, 0)

        def EQ(self):
            return self.getToken(BKOOLParser.EQ, 0)

        def exp(self):
            return self.getTypedRuleContext(BKOOLParser.ExpContext,0)


        def COMMA(self):
            return self.getToken(BKOOLParser.COMMA, 0)

        def getRuleIndex(self):
            return BKOOLParser.RULE_assignstmt

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAssignstmt" ):
                return visitor.visitAssignstmt(self)
            else:
                return visitor.visitChildren(self)




    def assignstmt(self):

        localctx = BKOOLParser.AssignstmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_assignstmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 97
            self.match(BKOOLParser.ID)
            self.state = 98
            self.match(BKOOLParser.EQ)
            self.state = 99
            self.exp()
            self.state = 100
            self.match(BKOOLParser.COMMA)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CallstmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(BKOOLParser.ID, 0)

        def LB(self):
            return self.getToken(BKOOLParser.LB, 0)

        def explist(self):
            return self.getTypedRuleContext(BKOOLParser.ExplistContext,0)


        def RB(self):
            return self.getToken(BKOOLParser.RB, 0)

        def COMMA(self):
            return self.getToken(BKOOLParser.COMMA, 0)

        def getRuleIndex(self):
            return BKOOLParser.RULE_callstmt

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCallstmt" ):
                return visitor.visitCallstmt(self)
            else:
                return visitor.visitChildren(self)




    def callstmt(self):

        localctx = BKOOLParser.CallstmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_callstmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 102
            self.match(BKOOLParser.ID)
            self.state = 103
            self.match(BKOOLParser.LB)
            self.state = 104
            self.explist()
            self.state = 105
            self.match(BKOOLParser.RB)
            self.state = 106
            self.match(BKOOLParser.COMMA)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ReturnstmtContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def exp(self):
            return self.getTypedRuleContext(BKOOLParser.ExpContext,0)


        def COMMA(self):
            return self.getToken(BKOOLParser.COMMA, 0)

        def getRuleIndex(self):
            return BKOOLParser.RULE_returnstmt

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitReturnstmt" ):
                return visitor.visitReturnstmt(self)
            else:
                return visitor.visitChildren(self)




    def returnstmt(self):

        localctx = BKOOLParser.ReturnstmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_returnstmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 108
            self.match(BKOOLParser.T__0)
            self.state = 109
            self.exp()
            self.state = 110
            self.match(BKOOLParser.COMMA)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParamdeclContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(BKOOLParser.ID, 0)

        def SEMI(self):
            return self.getToken(BKOOLParser.SEMI, 0)

        def paramdecl(self):
            return self.getTypedRuleContext(BKOOLParser.ParamdeclContext,0)


        def getRuleIndex(self):
            return BKOOLParser.RULE_paramdecl

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParamdecl" ):
                return visitor.visitParamdecl(self)
            else:
                return visitor.visitChildren(self)




    def paramdecl(self):

        localctx = BKOOLParser.ParamdeclContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_paramdecl)
        try:
            self.state = 116
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 112
                self.match(BKOOLParser.ID)
                self.state = 113
                self.match(BKOOLParser.SEMI)
                self.state = 114
                self.paramdecl()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)

                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExpContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def exp1(self):
            return self.getTypedRuleContext(BKOOLParser.Exp1Context,0)


        def ADD(self):
            return self.getToken(BKOOLParser.ADD, 0)

        def exp(self):
            return self.getTypedRuleContext(BKOOLParser.ExpContext,0)


        def getRuleIndex(self):
            return BKOOLParser.RULE_exp

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExp" ):
                return visitor.visitExp(self)
            else:
                return visitor.visitChildren(self)




    def exp(self):

        localctx = BKOOLParser.ExpContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_exp)
        try:
            self.state = 123
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,7,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 118
                self.exp1()
                self.state = 119
                self.match(BKOOLParser.ADD)
                self.state = 120
                self.exp()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 122
                self.exp1()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Exp1Context(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def exp2(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(BKOOLParser.Exp2Context)
            else:
                return self.getTypedRuleContext(BKOOLParser.Exp2Context,i)


        def SUB(self):
            return self.getToken(BKOOLParser.SUB, 0)

        def getRuleIndex(self):
            return BKOOLParser.RULE_exp1

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExp1" ):
                return visitor.visitExp1(self)
            else:
                return visitor.visitChildren(self)




    def exp1(self):

        localctx = BKOOLParser.Exp1Context(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_exp1)
        try:
            self.state = 130
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,8,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 125
                self.exp2(0)
                self.state = 126
                self.match(BKOOLParser.SUB)
                self.state = 127
                self.exp2(0)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 129
                self.exp2(0)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Exp2Context(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def exp3(self):
            return self.getTypedRuleContext(BKOOLParser.Exp3Context,0)


        def exp2(self):
            return self.getTypedRuleContext(BKOOLParser.Exp2Context,0)


        def MUL(self):
            return self.getToken(BKOOLParser.MUL, 0)

        def DIV(self):
            return self.getToken(BKOOLParser.DIV, 0)

        def getRuleIndex(self):
            return BKOOLParser.RULE_exp2

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExp2" ):
                return visitor.visitExp2(self)
            else:
                return visitor.visitChildren(self)



    def exp2(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = BKOOLParser.Exp2Context(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 32
        self.enterRecursionRule(localctx, 32, self.RULE_exp2, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 133
            self.exp3()
            self._ctx.stop = self._input.LT(-1)
            self.state = 140
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,9,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = BKOOLParser.Exp2Context(self, _parentctx, _parentState)
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_exp2)
                    self.state = 135
                    if not self.precpred(self._ctx, 2):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                    self.state = 136
                    _la = self._input.LA(1)
                    if not(_la==BKOOLParser.MUL or _la==BKOOLParser.DIV):
                        self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume()
                    self.state = 137
                    self.exp3() 
                self.state = 142
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,9,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class Exp3Context(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INTLIT(self):
            return self.getToken(BKOOLParser.INTLIT, 0)

        def FLOATLIT(self):
            return self.getToken(BKOOLParser.FLOATLIT, 0)

        def ID(self):
            return self.getToken(BKOOLParser.ID, 0)

        def callexp(self):
            return self.getTypedRuleContext(BKOOLParser.CallexpContext,0)


        def subexp(self):
            return self.getTypedRuleContext(BKOOLParser.SubexpContext,0)


        def getRuleIndex(self):
            return BKOOLParser.RULE_exp3

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExp3" ):
                return visitor.visitExp3(self)
            else:
                return visitor.visitChildren(self)




    def exp3(self):

        localctx = BKOOLParser.Exp3Context(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_exp3)
        try:
            self.state = 148
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,10,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 143
                self.match(BKOOLParser.INTLIT)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 144
                self.match(BKOOLParser.FLOATLIT)
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 145
                self.match(BKOOLParser.ID)
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 146
                self.callexp()
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 147
                self.subexp()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CallexpContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(BKOOLParser.ID, 0)

        def LB(self):
            return self.getToken(BKOOLParser.LB, 0)

        def explist(self):
            return self.getTypedRuleContext(BKOOLParser.ExplistContext,0)


        def RB(self):
            return self.getToken(BKOOLParser.RB, 0)

        def getRuleIndex(self):
            return BKOOLParser.RULE_callexp

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitCallexp" ):
                return visitor.visitCallexp(self)
            else:
                return visitor.visitChildren(self)




    def callexp(self):

        localctx = BKOOLParser.CallexpContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_callexp)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 150
            self.match(BKOOLParser.ID)
            self.state = 151
            self.match(BKOOLParser.LB)
            self.state = 152
            self.explist()
            self.state = 153
            self.match(BKOOLParser.RB)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class SubexpContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LB(self):
            return self.getToken(BKOOLParser.LB, 0)

        def exp(self):
            return self.getTypedRuleContext(BKOOLParser.ExpContext,0)


        def RB(self):
            return self.getToken(BKOOLParser.RB, 0)

        def getRuleIndex(self):
            return BKOOLParser.RULE_subexp

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSubexp" ):
                return visitor.visitSubexp(self)
            else:
                return visitor.visitChildren(self)




    def subexp(self):

        localctx = BKOOLParser.SubexpContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_subexp)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 155
            self.match(BKOOLParser.LB)
            self.state = 156
            self.exp()
            self.state = 157
            self.match(BKOOLParser.RB)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExplistContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def exp(self):
            return self.getTypedRuleContext(BKOOLParser.ExpContext,0)


        def SEMI(self, i:int=None):
            if i is None:
                return self.getTokens(BKOOLParser.SEMI)
            else:
                return self.getToken(BKOOLParser.SEMI, i)

        def explist(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(BKOOLParser.ExplistContext)
            else:
                return self.getTypedRuleContext(BKOOLParser.ExplistContext,i)


        def getRuleIndex(self):
            return BKOOLParser.RULE_explist

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExplist" ):
                return visitor.visitExplist(self)
            else:
                return visitor.visitChildren(self)




    def explist(self):

        localctx = BKOOLParser.ExplistContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_explist)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 167
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & ((1 << BKOOLParser.LB) | (1 << BKOOLParser.ID) | (1 << BKOOLParser.INTLIT) | (1 << BKOOLParser.FLOATLIT))) != 0):
                self.state = 159
                self.exp()
                self.state = 164
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,11,self._ctx)
                while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                    if _alt==1:
                        self.state = 160
                        self.match(BKOOLParser.SEMI)
                        self.state = 161
                        self.explist() 
                    self.state = 166
                    self._errHandler.sync(self)
                    _alt = self._interp.adaptivePredict(self._input,11,self._ctx)



        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TpContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT(self):
            return self.getToken(BKOOLParser.INT, 0)

        def FLOAT(self):
            return self.getToken(BKOOLParser.FLOAT, 0)

        def getRuleIndex(self):
            return BKOOLParser.RULE_tp

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTp" ):
                return visitor.visitTp(self)
            else:
                return visitor.visitChildren(self)




    def tp(self):

        localctx = BKOOLParser.TpContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_tp)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 169
            _la = self._input.LA(1)
            if not(_la==BKOOLParser.INT or _la==BKOOLParser.FLOAT):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class IdlistContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ID(self):
            return self.getToken(BKOOLParser.ID, 0)

        def SEMI(self):
            return self.getToken(BKOOLParser.SEMI, 0)

        def idlist(self):
            return self.getTypedRuleContext(BKOOLParser.IdlistContext,0)


        def getRuleIndex(self):
            return BKOOLParser.RULE_idlist

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitIdlist" ):
                return visitor.visitIdlist(self)
            else:
                return visitor.visitChildren(self)




    def idlist(self):

        localctx = BKOOLParser.IdlistContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_idlist)
        try:
            self.state = 175
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,13,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 171
                self.match(BKOOLParser.ID)
                self.state = 172
                self.match(BKOOLParser.SEMI)
                self.state = 173
                self.idlist()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 174
                self.match(BKOOLParser.ID)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[16] = self.exp2_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def exp2_sempred(self, localctx:Exp2Context, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 2)
         




