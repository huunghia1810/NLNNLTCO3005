# Generated from main/bkool/parser/BKOOL.g4 by ANTLR 4.9.2
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .BKOOLParser import BKOOLParser
else:
    from BKOOLParser import BKOOLParser

# This class defines a complete generic visitor for a parse tree produced by BKOOLParser.

class BKOOLVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by BKOOLParser#program.
    def visitProgram(self, ctx:BKOOLParser.ProgramContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by BKOOLParser#funcdecl.
    def visitFuncdecl(self, ctx:BKOOLParser.FuncdeclContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by BKOOLParser#paramdef.
    def visitParamdef(self, ctx:BKOOLParser.ParamdefContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by BKOOLParser#paramlist.
    def visitParamlist(self, ctx:BKOOLParser.ParamlistContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by BKOOLParser#parampatch.
    def visitParampatch(self, ctx:BKOOLParser.ParampatchContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by BKOOLParser#param.
    def visitParam(self, ctx:BKOOLParser.ParamContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by BKOOLParser#body.
    def visitBody(self, ctx:BKOOLParser.BodyContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by BKOOLParser#stmtlist.
    def visitStmtlist(self, ctx:BKOOLParser.StmtlistContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by BKOOLParser#stmt.
    def visitStmt(self, ctx:BKOOLParser.StmtContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by BKOOLParser#vardecl.
    def visitVardecl(self, ctx:BKOOLParser.VardeclContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by BKOOLParser#assignstmt.
    def visitAssignstmt(self, ctx:BKOOLParser.AssignstmtContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by BKOOLParser#callstmt.
    def visitCallstmt(self, ctx:BKOOLParser.CallstmtContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by BKOOLParser#returnstmt.
    def visitReturnstmt(self, ctx:BKOOLParser.ReturnstmtContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by BKOOLParser#paramdecl.
    def visitParamdecl(self, ctx:BKOOLParser.ParamdeclContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by BKOOLParser#exp.
    def visitExp(self, ctx:BKOOLParser.ExpContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by BKOOLParser#exp1.
    def visitExp1(self, ctx:BKOOLParser.Exp1Context):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by BKOOLParser#exp2.
    def visitExp2(self, ctx:BKOOLParser.Exp2Context):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by BKOOLParser#exp3.
    def visitExp3(self, ctx:BKOOLParser.Exp3Context):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by BKOOLParser#callexp.
    def visitCallexp(self, ctx:BKOOLParser.CallexpContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by BKOOLParser#subexp.
    def visitSubexp(self, ctx:BKOOLParser.SubexpContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by BKOOLParser#explist.
    def visitExplist(self, ctx:BKOOLParser.ExplistContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by BKOOLParser#tp.
    def visitTp(self, ctx:BKOOLParser.TpContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by BKOOLParser#idlist.
    def visitIdlist(self, ctx:BKOOLParser.IdlistContext):
        return self.visitChildren(ctx)



del BKOOLParser